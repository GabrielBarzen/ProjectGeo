package se.gabnet.projectgeo

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ProjectgeoApplicationTests {

	@Test
	fun contextLoads() {
	}

}
